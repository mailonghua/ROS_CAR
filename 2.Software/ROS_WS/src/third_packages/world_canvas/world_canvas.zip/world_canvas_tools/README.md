World canvas tools
==================

Tools for manipulating semantic maps within the world canvas framework.
